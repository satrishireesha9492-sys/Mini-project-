# 📝 CollabNotes v2 — Enhanced Edition

A collaborative note-taking app built with Python + Streamlit, upgraded with full user management, real-time collaboration presence, rich sharing, version diffing, and expanded AI tools.

## ✅ Features

### Auth
- Register / login with email + password (SHA-256 hashed)
- Email format validation
- Password confirmation on register
- Session management with sign-out

### Notes
- Create, edit, delete notes
- Auto word count
- Tag management (add, edit, remove)
- Full-text search (title, content, tags)
- Time-ago display ("3m ago")
- Notes grid with owner/shared badge

### Real-time Collaboration (Presence)
- Live "Active now" panel shows who's viewing the note (30s window)
- Animated presence dot per active user
- Invite collaborators by email (must have an account)
- Share via token (read or write permission)
- Revoke share tokens
- Remove collaborators
- Collaborator list with avatars and permission badges

### Version History
- Save versions with optional description
- View/preview any past version inline
- Restore to any past version (creates a new version)
- Version metadata: who saved, when, description

### AI Features (requires Anthropic API key)
- **Summarize** — bullet-point summary
- **Ask** — Q&A grounded in note content
- **Improve** — AI rewrites/enhances the note
- **Action Items** — extracts tasks and to-dos
- **Auto-tag** — generates and applies tags

## 🚀 Run

```bash
pip install -r requirements.txt
streamlit run app.py
```

Open http://localhost:8501

## ⚙️ AI Setup

Set your API key in Dashboard → Sidebar → AI Settings, or:

```bash
export ANTHROPIC_API_KEY=sk-ant-...
streamlit run app.py
```

Get a key at https://console.anthropic.com

## 📁 Files

- `app.py` — full application (~600 lines)
- `requirements.txt` — pip dependencies
- `notes_data.json` — auto-created on first use (users, notes, presence)
